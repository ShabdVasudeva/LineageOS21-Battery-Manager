package org.lineageos.batterymanager;
import android.app.Application;
import com.google.android.material.color.DynamicColors;
import org.w3c.dom.Text;

public class AppName extends Application {
    @Override
    public void onCreate() {
    	super.onCreate();
        DynamicColors.applyToActivitiesIfAvailable(this);
    }
}
